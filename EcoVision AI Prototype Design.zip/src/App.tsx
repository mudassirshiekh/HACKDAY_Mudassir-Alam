import { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { UploadPage } from './components/UploadPage';
import { ResultsDashboard } from './components/ResultsDashboard';
import { PosterPage } from './components/PosterPage';
import { TipsHistoryPage } from './components/TipsHistoryPage';

type Page = 'home' | 'upload' | 'results' | 'poster' | 'tips';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [uploadedImage, setUploadedImage] = useState<string | undefined>();

  const handleNavigate = (page: string, imageUrl?: string) => {
    setCurrentPage(page as Page);
    if (imageUrl) {
      setUploadedImage(imageUrl);
    }
    // Scroll to top on navigation
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="size-full">
      {currentPage === 'home' && <LandingPage onNavigate={handleNavigate} />}
      {currentPage === 'upload' && <UploadPage onNavigate={handleNavigate} />}
      {currentPage === 'results' && (
        <ResultsDashboard onNavigate={handleNavigate} uploadedImage={uploadedImage} />
      )}
      {currentPage === 'poster' && (
        <PosterPage onNavigate={handleNavigate} uploadedImage={uploadedImage} />
      )}
      {currentPage === 'tips' && <TipsHistoryPage onNavigate={handleNavigate} />}
    </div>
  );
}
