import { motion } from 'motion/react';
import { ArrowLeft, Leaf, Droplets, Wind, History, Lightbulb, Home, Upload, BookOpen } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

interface TipsHistoryPageProps {
  onNavigate: (page: string) => void;
}

const historyData = [
  {
    id: 1,
    date: 'Oct 10, 2025',
    type: 'Air Pollution',
    level: 'High',
    score: 78,
    icon: Wind,
    color: 'from-sky-400 to-blue-500'
  },
  {
    id: 2,
    date: 'Oct 9, 2025',
    type: 'Water Pollution',
    level: 'Medium',
    score: 52,
    icon: Droplets,
    color: 'from-cyan-400 to-teal-500'
  },
  {
    id: 3,
    date: 'Oct 8, 2025',
    type: 'Land Pollution',
    level: 'Low',
    score: 31,
    icon: Leaf,
    color: 'from-emerald-400 to-green-500'
  }
];

const dailyTips = [
  {
    title: 'Use Reusable Shopping Bags',
    description: 'Replace plastic bags with reusable cloth bags to reduce waste and pollution.',
    icon: '🛍️',
    impact: 'High Impact'
  },
  {
    title: 'Conserve Water Daily',
    description: 'Turn off taps while brushing, fix leaks, and use water-efficient appliances.',
    icon: '💧',
    impact: 'Medium Impact'
  },
  {
    title: 'Plant a Tree This Month',
    description: 'Trees absorb CO2, provide oxygen, and help combat climate change effectively.',
    icon: '🌳',
    impact: 'High Impact'
  }
];

const ecoFacts = [
  'A single tree can absorb up to 48 pounds of CO2 per year',
  'Recycling one aluminum can saves enough energy to run a TV for 3 hours',
  'Plastic takes 400+ years to decompose in landfills',
  'LED bulbs use 75% less energy than traditional bulbs',
  'Ocean pollution affects over 100,000 marine animals yearly',
  'Composting can reduce waste by up to 30%'
];

export function TipsHistoryPage({ onNavigate }: TipsHistoryPageProps) {
  const getRiskColor = (level: string) => {
    switch (level) {
      case 'High': return 'bg-red-500';
      case 'Medium': return 'bg-yellow-500';
      case 'Low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-sky-50 to-green-50">
      <div className="container mx-auto px-4 py-8 lg:py-12 max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Button
            onClick={() => onNavigate('home')}
            variant="ghost"
            className="mb-4 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="mr-2" size={20} />
            Back to Home
          </Button>
          <h1 className="text-gray-800 mb-2">Tips & History</h1>
          <p className="text-gray-600">
            Your environmental journey and actionable eco-tips
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content - Left Side */}
          <div className="lg:col-span-2 space-y-6">
            {/* Daily Tips Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="p-6 bg-white/80 backdrop-blur-sm">
                <div className="flex items-center gap-2 mb-6">
                  <Lightbulb className="text-emerald-600" size={24} />
                  <h2 className="text-gray-800">3 Things You Can Do Today to Save the Planet</h2>
                </div>
                <div className="space-y-4">
                  {dailyTips.map((tip, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.3 + index * 0.1 }}
                      className="flex gap-4 p-4 bg-gradient-to-r from-emerald-50 to-green-50 rounded-xl border border-emerald-100 hover:shadow-md transition-all duration-300"
                    >
                      <div className="text-4xl">{tip.icon}</div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-gray-800">{tip.title}</h3>
                          <Badge className="bg-emerald-100 text-emerald-700 text-xs">
                            {tip.impact}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600">{tip.description}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </Card>
            </motion.div>

            {/* Analysis History */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Card className="p-6 bg-white/80 backdrop-blur-sm">
                <div className="flex items-center gap-2 mb-6">
                  <History className="text-emerald-600" size={24} />
                  <h2 className="text-gray-800">Recent Analysis History</h2>
                </div>
                <div className="space-y-3">
                  {historyData.map((item, index) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.6 + index * 0.1 }}
                      className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                    >
                      <div className={`p-3 rounded-lg bg-gradient-to-br ${item.color}`}>
                        <item.icon className="text-white" size={24} />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-gray-800 mb-1">{item.type}</h4>
                        <p className="text-sm text-gray-500">{item.date}</p>
                      </div>
                      <div className="text-right">
                        <Badge className={`${getRiskColor(item.level)} text-white mb-1`}>
                          {item.level}
                        </Badge>
                        <p className="text-sm text-gray-600">{item.score}%</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </Card>
            </motion.div>

            {/* Eco Facts */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
            >
              <Card className="p-6 bg-gradient-to-br from-emerald-500 to-green-600 text-white">
                <div className="flex items-center gap-2 mb-4">
                  <BookOpen size={24} />
                  <h2>Did You Know?</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {ecoFacts.map((fact, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.9 + index * 0.05 }}
                      className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20"
                    >
                      <p className="text-sm">{fact}</p>
                    </motion.div>
                  ))}
                </div>
              </Card>
            </motion.div>
          </div>

          {/* Sidebar - Right Side */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="p-6 bg-white/80 backdrop-blur-sm">
                <h3 className="text-gray-800 mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Button
                    onClick={() => onNavigate('home')}
                    variant="outline"
                    className="w-full justify-start border-2 border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                  >
                    <Home className="mr-2" size={20} />
                    Go to Home
                  </Button>
                  <Button
                    onClick={() => onNavigate('upload')}
                    className="w-full justify-start bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white"
                  >
                    <Upload className="mr-2" size={20} />
                    Upload New Image
                  </Button>
                </div>
              </Card>
            </motion.div>

            {/* Stats Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="p-6 bg-white/80 backdrop-blur-sm">
                <h3 className="text-gray-800 mb-4">Your Impact</h3>
                <div className="space-y-4">
                  <div className="text-center p-4 bg-emerald-50 rounded-lg border border-emerald-100">
                    <p className="text-3xl mb-1">12</p>
                    <p className="text-sm text-gray-600">Total Analyses</p>
                  </div>
                  <div className="text-center p-4 bg-sky-50 rounded-lg border border-sky-100">
                    <p className="text-3xl mb-1">8</p>
                    <p className="text-sm text-gray-600">Posters Created</p>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg border border-green-100">
                    <p className="text-3xl mb-1">47</p>
                    <p className="text-sm text-gray-600">Tips Viewed</p>
                  </div>
                </div>
              </Card>
            </motion.div>

            {/* Achievement Badge */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Card className="p-6 bg-gradient-to-br from-yellow-400 to-orange-500 text-white text-center">
                <motion.div
                  animate={{
                    rotate: [0, 5, -5, 0],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="text-5xl mb-2"
                >
                  🏆
                </motion.div>
                <h3 className="mb-1">Eco Warrior</h3>
                <p className="text-sm opacity-90">
                  Keep making a difference!
                </p>
              </Card>
            </motion.div>
          </div>
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
          className="mt-8 text-center"
        >
          <Card className="p-8 bg-white/80 backdrop-blur-sm">
            <Leaf className="mx-auto text-emerald-600 mb-4" size={48} />
            <h2 className="text-gray-800 mb-2">Ready to Make a Difference?</h2>
            <p className="text-gray-600 mb-6">
              Upload another image to continue your environmental awareness journey
            </p>
            <Button
              onClick={() => onNavigate('upload')}
              className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white px-8 py-6 rounded-xl"
            >
              <Upload className="mr-2" size={20} />
              Start New Analysis
            </Button>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
