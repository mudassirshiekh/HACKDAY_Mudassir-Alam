import { motion } from 'motion/react';
import { Upload, Sparkles, Leaf, Droplets, Wind } from 'lucide-react';
import { Button } from './ui/button';

interface LandingPageProps {
  onNavigate: (page: string) => void;
}

export function LandingPage({ onNavigate }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-sky-50 to-green-50 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{
            y: [0, -20, 0],
            x: [0, 10, 0],
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-20 left-10 text-emerald-300/30"
        >
          <Leaf size={120} />
        </motion.div>
        <motion.div
          animate={{
            y: [0, 20, 0],
            x: [0, -15, 0],
          }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-40 right-20 text-sky-300/30"
        >
          <Droplets size={100} />
        </motion.div>
        <motion.div
          animate={{
            rotate: [0, 360],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-1/3 right-1/4 text-green-300/20"
        >
          <Wind size={80} />
        </motion.div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-4 py-12 lg:py-20">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center max-w-5xl mx-auto"
        >
          {/* Logo/Icon */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-emerald-500 to-green-600 rounded-3xl mb-8 shadow-2xl"
          >
            <Sparkles className="text-white" size={48} />
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-4xl lg:text-6xl mb-6 bg-gradient-to-r from-emerald-600 via-green-600 to-sky-600 bg-clip-text text-transparent"
          >
            EcoVision AI
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-xl lg:text-2xl text-gray-700 mb-4"
          >
            Environmental Awareness in Real Time
          </motion.p>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-lg text-gray-600 mb-12 max-w-2xl mx-auto"
          >
            Detect pollution and generate actionable eco-tips instantly with the power of AI
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <Button
              onClick={() => onNavigate('upload')}
              className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white px-8 py-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 group"
            >
              <Upload className="mr-2 group-hover:scale-110 transition-transform" size={20} />
              Upload Image
            </Button>
            <Button
              onClick={() => onNavigate('tips')}
              variant="outline"
              className="border-2 border-emerald-500 text-emerald-700 hover:bg-emerald-50 px-8 py-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300"
            >
              <Sparkles className="mr-2" size={20} />
              Explore Features
            </Button>
          </motion.div>
        </motion.div>

        {/* Feature Cards */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20 max-w-5xl mx-auto"
        >
          {[
            {
              icon: Wind,
              title: "Air Quality Detection",
              description: "Analyze air pollution levels and get instant feedback",
              color: "from-sky-400 to-blue-500"
            },
            {
              icon: Droplets,
              title: "Water Purity Check",
              description: "Detect water contamination and pollution sources",
              color: "from-cyan-400 to-teal-500"
            },
            {
              icon: Leaf,
              title: "Land Pollution Analysis",
              description: "Identify waste and environmental degradation",
              color: "from-emerald-400 to-green-500"
            }
          ].map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9 + index * 0.1 }}
              whileHover={{ y: -8, scale: 1.02, transition: { duration: 0.2 } }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onNavigate('upload')}
              className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 cursor-pointer group"
            >
              <motion.div 
                className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${feature.color} mb-4 group-hover:scale-110 transition-transform duration-300`}
              >
                <feature.icon className="text-white" size={28} />
              </motion.div>
              <h3 className="text-gray-800 mb-2 group-hover:text-emerald-600 transition-colors">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
              <div className="mt-4 flex items-center text-emerald-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span className="text-sm">Get Started</span>
                <motion.span
                  animate={{ x: [0, 4, 0] }}
                  transition={{ duration: 1, repeat: Infinity }}
                  className="ml-1"
                >
                  →
                </motion.span>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Footer */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-6 left-0 right-0 text-center text-sm text-gray-500"
      >
        <p>Powered by Gemini AI | Designed by Mudassir Alam | HackDay 2025</p>
      </motion.div>
    </div>
  );
}
