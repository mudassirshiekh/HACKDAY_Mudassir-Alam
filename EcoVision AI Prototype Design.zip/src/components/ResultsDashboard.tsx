import { motion } from 'motion/react';
import { ArrowLeft, Wind, Droplets, Leaf, TrendingUp, FileText, Download } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface ResultsDashboardProps {
  onNavigate: (page: string, imageUrl?: string) => void;
  uploadedImage?: string;
}

const pollutionData = [
  {
    type: 'Air',
    icon: Wind,
    level: 'High',
    percentage: 78,
    color: 'from-sky-400 to-blue-500',
    bgColor: 'bg-sky-50',
    borderColor: 'border-sky-200',
    insight: 'Significant particulate matter detected in the atmosphere. Air quality index suggests potential health risks for sensitive groups.',
    tips: [
      'Use public transportation or carpool',
      'Plant more trees in urban areas',
      'Support clean energy initiatives'
    ]
  },
  {
    type: 'Water',
    icon: Droplets,
    level: 'Medium',
    percentage: 52,
    color: 'from-cyan-400 to-teal-500',
    bgColor: 'bg-cyan-50',
    borderColor: 'border-cyan-200',
    insight: 'Water samples show moderate contamination levels. Presence of microplastics and chemical runoff detected.',
    tips: [
      'Reduce plastic usage in daily life',
      'Support water treatment programs',
      'Avoid dumping waste in water bodies'
    ]
  },
  {
    type: 'Land',
    icon: Leaf,
    level: 'Low',
    percentage: 31,
    color: 'from-emerald-400 to-green-500',
    bgColor: 'bg-emerald-50',
    borderColor: 'border-emerald-200',
    insight: 'Minimal land degradation observed. Soil quality appears healthy with good vegetation cover.',
    tips: [
      'Practice composting organic waste',
      'Support local recycling programs',
      'Reduce single-use items'
    ]
  }
];

const chartData = [
  { name: 'Air', value: 78 },
  { name: 'Water', value: 52 },
  { name: 'Land', value: 31 }
];

const awarenessActions = [
  'Reduce, Reuse, Recycle - Make it a daily habit',
  'Switch to renewable energy sources when possible',
  'Conserve water by fixing leaks and using efficiently',
  'Choose sustainable and eco-friendly products',
  'Spread awareness about environmental protection',
  'Participate in community clean-up drives'
];

export function ResultsDashboard({ onNavigate, uploadedImage }: ResultsDashboardProps) {
  const getRiskColor = (level: string) => {
    switch (level) {
      case 'High': return 'bg-red-500';
      case 'Medium': return 'bg-yellow-500';
      case 'Low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-sky-50 to-green-50">
      <div className="container mx-auto px-4 py-8 lg:py-12 max-w-7xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Button
            onClick={() => onNavigate('upload')}
            variant="ghost"
            className="mb-4 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="mr-2" size={20} />
            Upload New Image
          </Button>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h1 className="text-gray-800 mb-2">Analysis Results</h1>
              <p className="text-gray-600">AI-powered environmental pollution detection</p>
            </div>
            <Button
              onClick={() => onNavigate('poster', uploadedImage)}
              className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white px-6 py-6 rounded-xl"
            >
              <FileText className="mr-2" size={20} />
              Generate Awareness Poster
            </Button>
          </div>
        </motion.div>

        {/* Uploaded Image Preview */}
        {uploadedImage && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-8"
          >
            <Card className="p-4 bg-white/80 backdrop-blur-sm">
              <div className="flex items-center gap-4">
                <img
                  src={uploadedImage}
                  alt="Analyzed"
                  className="w-24 h-24 object-cover rounded-lg"
                />
                <div>
                  <h3 className="text-gray-800 mb-1">Analyzed Image</h3>
                  <p className="text-sm text-gray-600">Processed by Gemini AI</p>
                </div>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Pollution Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8"
        >
          {pollutionData.map((pollution, index) => (
            <motion.div
              key={pollution.type}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
            >
              <Card className={`p-6 ${pollution.bgColor} border-2 ${pollution.borderColor} hover:shadow-xl transition-all duration-300`}>
                <div className="flex items-start justify-between mb-4">
                  <div className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${pollution.color}`}>
                    <pollution.icon className="text-white" size={28} />
                  </div>
                  <Badge className={`${getRiskColor(pollution.level)} text-white`}>
                    {pollution.level} Risk
                  </Badge>
                </div>
                <h3 className="text-gray-800 mb-2">{pollution.type} Pollution</h3>
                <p className="text-sm text-gray-600 mb-4">{pollution.insight}</p>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Pollution Level</span>
                    <span className="text-gray-800">{pollution.percentage}%</span>
                  </div>
                  <Progress value={pollution.percentage} className="h-2" />
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Chart Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8"
        >
          <Card className="p-6 bg-white/80 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="text-emerald-600" size={24} />
              <h3 className="text-gray-800">Pollution Intensity Overview</h3>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="value" fill="url(#colorGradient)" radius={[8, 8, 0, 0]} />
                <defs>
                  <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" />
                    <stop offset="100%" stopColor="#059669" />
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          </Card>

          {/* Quick Stats */}
          <Card className="p-6 bg-white/80 backdrop-blur-sm">
            <h3 className="text-gray-800 mb-4">Environmental Impact Summary</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-100">
                <span className="text-gray-700">Critical Areas</span>
                <span className="text-red-600">1 detected</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg border border-yellow-100">
                <span className="text-gray-700">Moderate Concerns</span>
                <span className="text-yellow-600">1 detected</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-100">
                <span className="text-gray-700">Healthy Areas</span>
                <span className="text-green-600">1 detected</span>
              </div>
              <div className="mt-6 p-4 bg-gradient-to-r from-emerald-500 to-green-600 rounded-lg text-white">
                <p className="text-sm">Overall Environmental Health Score</p>
                <p className="text-2xl mt-1">54/100</p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Awareness Tips */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <Card className="p-6 lg:p-8 bg-white/80 backdrop-blur-sm">
            <h3 className="text-gray-800 mb-6">🌱 Actionable Eco-Tips</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {awarenessActions.map((tip, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.9 + index * 0.05 }}
                  className="flex items-start gap-3 p-4 bg-emerald-50 rounded-lg border border-emerald-100 hover:shadow-md transition-shadow"
                >
                  <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center flex-shrink-0 text-sm">
                    {index + 1}
                  </div>
                  <p className="text-sm text-gray-700">{tip}</p>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="flex flex-col sm:flex-row gap-4 justify-center mt-8"
        >
          <Button
            onClick={() => onNavigate('poster', uploadedImage)}
            className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white px-8 py-6 rounded-xl"
          >
            <FileText className="mr-2" size={20} />
            Generate Awareness Poster
          </Button>
          <Button
            onClick={() => onNavigate('tips')}
            variant="outline"
            className="border-2 border-emerald-500 text-emerald-700 hover:bg-emerald-50 px-8 py-6 rounded-xl"
          >
            View Tips & History
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
