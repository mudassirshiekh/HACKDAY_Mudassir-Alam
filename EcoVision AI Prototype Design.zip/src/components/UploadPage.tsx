import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, Image as ImageIcon, Loader2, ArrowLeft, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface UploadPageProps {
  onNavigate: (page: string, imageUrl?: string) => void;
}

export function UploadPage({ onNavigate }: UploadPageProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setSelectedImage(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      handleFileSelect(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleAnalyze = () => {
    setIsAnalyzing(true);
    // Simulate AI analysis
    setTimeout(() => {
      onNavigate('results', selectedImage || undefined);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-sky-50 to-green-50">
      <div className="container mx-auto px-4 py-8 lg:py-12 max-w-4xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Button
            onClick={() => onNavigate('home')}
            variant="ghost"
            className="mb-4 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="mr-2" size={20} />
            Back to Home
          </Button>
          <h1 className="text-gray-800 mb-2">Upload Image for Analysis</h1>
          <p className="text-gray-600">
            Upload an image to detect pollution and receive AI-powered environmental insights
          </p>
        </motion.div>

        {/* Upload Area */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="p-8 lg:p-12 bg-white/80 backdrop-blur-sm border-2 border-dashed border-gray-300 hover:border-emerald-400 transition-all duration-300">
            {!selectedImage ? (
              <div
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                className={`text-center ${isDragging ? 'scale-105' : ''} transition-transform duration-200`}
              >
                <motion.div
                  animate={{
                    y: isDragging ? -10 : 0,
                  }}
                  className={`inline-flex items-center justify-center w-20 h-20 rounded-full mb-6 ${
                    isDragging
                      ? 'bg-gradient-to-br from-emerald-400 to-green-500'
                      : 'bg-gradient-to-br from-emerald-100 to-green-100'
                  }`}
                >
                  <Upload
                    className={isDragging ? 'text-white' : 'text-emerald-600'}
                    size={40}
                  />
                </motion.div>
                <h3 className="text-gray-800 mb-2">
                  Drag & Drop your image here
                </h3>
                <p className="text-gray-500 mb-6">or</p>
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white px-8 py-6 rounded-xl"
                >
                  <ImageIcon className="mr-2" size={20} />
                  Browse Files
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileSelect(file);
                  }}
                  className="hidden"
                />
                <p className="text-sm text-gray-400 mt-4">
                  Supports: JPG, PNG, WEBP (Max 10MB)
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="relative rounded-xl overflow-hidden shadow-lg"
                >
                  <img
                    src={selectedImage}
                    alt="Selected"
                    className="w-full h-auto max-h-96 object-cover"
                  />
                </motion.div>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    onClick={handleAnalyze}
                    disabled={isAnalyzing}
                    className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white px-8 py-6 rounded-xl flex-1 sm:flex-initial"
                  >
                    {!isAnalyzing && <Sparkles className="mr-2" size={20} />}
                    {isAnalyzing ? 'Analyzing...' : 'Analyze with AI'}
                  </Button>
                  <Button
                    onClick={() => setSelectedImage(null)}
                    variant="outline"
                    disabled={isAnalyzing}
                    className="border-2 border-gray-300 text-gray-700 hover:bg-gray-50 px-8 py-6 rounded-xl flex-1 sm:flex-initial"
                  >
                    Choose Different Image
                  </Button>
                </div>
              </div>
            )}
          </Card>
        </motion.div>

        {/* Loading Animation */}
        <AnimatePresence>
          {isAnalyzing && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center"
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="bg-white rounded-2xl p-12 text-center max-w-md mx-4"
              >
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-emerald-400 to-green-500 rounded-full mb-6"
                >
                  <Loader2 className="text-white" size={40} />
                </motion.div>
                <h3 className="text-gray-800 mb-2">Analyzing with Gemini AI...</h3>
                <p className="text-gray-600">
                  Detecting pollution patterns and generating insights
                </p>
                <motion.div
                  className="mt-6 h-2 bg-gray-200 rounded-full overflow-hidden"
                >
                  <motion.div
                    initial={{ width: "0%" }}
                    animate={{ width: "100%" }}
                    transition={{ duration: 3, ease: "easeInOut" }}
                    className="h-full bg-gradient-to-r from-emerald-500 to-green-600"
                  />
                </motion.div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Info Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8"
        >
          {[
            { title: "Fast Analysis", description: "Results in seconds" },
            { title: "AI-Powered", description: "Gemini technology" },
            { title: "Actionable Tips", description: "Eco-friendly solutions" }
          ].map((item, index) => (
            <Card key={index} className="p-4 bg-white/60 backdrop-blur-sm text-center">
              <h4 className="text-gray-800 mb-1">{item.title}</h4>
              <p className="text-sm text-gray-600">{item.description}</p>
            </Card>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
