import { useRef } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Download, Leaf, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface PosterPageProps {
  onNavigate: (page: string) => void;
  uploadedImage?: string;
}

export function PosterPage({ onNavigate, uploadedImage }: PosterPageProps) {
  const posterRef = useRef<HTMLDivElement>(null);

  const handleDownload = () => {
    // In a real app, this would use html2canvas or similar
    alert('In a production app, this would download the poster as PNG! For now, you can take a screenshot. 📸');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-sky-50 to-green-50">
      <div className="container mx-auto px-4 py-8 lg:py-12 max-w-5xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Button
            onClick={() => onNavigate('results')}
            variant="ghost"
            className="mb-4 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="mr-2" size={20} />
            Back to Results
          </Button>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h1 className="text-gray-800 mb-2">Awareness Poster</h1>
              <p className="text-gray-600">Share this message to spread environmental awareness</p>
            </div>
            <Button
              onClick={handleDownload}
              className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white px-6 py-6 rounded-xl"
            >
              <Download className="mr-2" size={20} />
              Download as PNG
            </Button>
          </div>
        </motion.div>

        {/* Poster */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <Card className="overflow-hidden bg-white shadow-2xl">
            <div
              ref={posterRef}
              className="relative aspect-[3/4] bg-gradient-to-br from-emerald-600 via-green-600 to-teal-600"
            >
              {/* Background Image Overlay */}
              {uploadedImage && (
                <div className="absolute inset-0 opacity-20">
                  <img
                    src={uploadedImage}
                    alt="Background"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              {/* Overlay Pattern */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />

              {/* Content */}
              <div className="relative h-full flex flex-col items-center justify-between p-8 lg:p-12 text-white">
                {/* Top Section */}
                <motion.div
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="text-center"
                >
                  <motion.div
                    animate={{
                      rotate: [0, 5, -5, 0],
                    }}
                    transition={{
                      duration: 4,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className="inline-flex items-center justify-center w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full mb-6"
                  >
                    <Leaf size={40} />
                  </motion.div>
                  <h2 className="text-3xl lg:text-5xl mb-4">
                    EcoVision AI
                  </h2>
                  <div className="w-24 h-1 bg-white/50 mx-auto rounded-full" />
                </motion.div>

                {/* Middle Section - Main Message */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.6 }}
                  className="text-center space-y-6 max-w-2xl"
                >
                  <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                    <Sparkles className="mx-auto mb-4" size={32} />
                    <h3 className="text-2xl lg:text-4xl mb-4 leading-tight">
                      "A Clean Environment is Everyone's Right"
                    </h3>
                    <p className="text-lg lg:text-xl opacity-90">
                      Together, we can make a difference for our planet
                    </p>
                  </div>

                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.8 }}
                    className="grid grid-cols-3 gap-4 mt-8"
                  >
                    {[
                      { icon: '🌍', text: 'Protect Earth' },
                      { icon: '♻️', text: 'Recycle More' },
                      { icon: '🌱', text: 'Plant Trees' }
                    ].map((item, index) => (
                      <div
                        key={index}
                        className="bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20"
                      >
                        <div className="text-3xl mb-2">{item.icon}</div>
                        <p className="text-sm">{item.text}</p>
                      </div>
                    ))}
                  </motion.div>
                </motion.div>

                {/* Bottom Section */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1 }}
                  className="text-center space-y-4"
                >
                  <div className="space-y-2">
                    <p className="text-lg">Take Action Today!</p>
                    <div className="flex items-center justify-center gap-2 text-sm opacity-80">
                      <span>Powered by Gemini AI</span>
                      <span>•</span>
                      <span>HackDay 2025</span>
                    </div>
                  </div>
                  <div className="w-32 h-1 bg-white/30 mx-auto rounded-full" />
                  <p className="text-sm opacity-70">
                    Designed by Mudassir Alam
                  </p>
                </motion.div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Info Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4"
        >
          <Card className="p-4 bg-white/60 backdrop-blur-sm text-center">
            <h4 className="text-gray-800 mb-1">High Quality</h4>
            <p className="text-sm text-gray-600">Ready for social media</p>
          </Card>
          <Card className="p-4 bg-white/60 backdrop-blur-sm text-center">
            <h4 className="text-gray-800 mb-1">Shareable</h4>
            <p className="text-sm text-gray-600">Spread awareness easily</p>
          </Card>
          <Card className="p-4 bg-white/60 backdrop-blur-sm text-center">
            <h4 className="text-gray-800 mb-1">AI Generated</h4>
            <p className="text-sm text-gray-600">Powered by Gemini</p>
          </Card>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-4 justify-center mt-8"
        >
          <Button
            onClick={handleDownload}
            className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white px-8 py-6 rounded-xl"
          >
            <Download className="mr-2" size={20} />
            Download Poster
          </Button>
          <Button
            onClick={() => onNavigate('upload')}
            variant="outline"
            className="border-2 border-emerald-500 text-emerald-700 hover:bg-emerald-50 px-8 py-6 rounded-xl"
          >
            Create Another Poster
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
